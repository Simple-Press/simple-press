# README #

This project is an extension designed to run on the Simple:Press Wordpress Theme Platform.  

### How do I get set up? ###

This theme is not a normal WordPress theme and cannot be installed via the WordPress THEMES screen.
Instead, you should:

- Download the theme file from your receipt or from your dashboard
- Go to FORUM->Themes
- click on `Theme Uploader`
- Click on the `Choose File` button and select the zip file you downloaded earlier
- Click the `Upload Now` button
- Go back to the FORUM->Themes screen and activate the theme.


### Change Log  ###
-----------------------------------------------------------------------------------------
###### 1.3.0
- Fix: Various fixes for WP 5.9.x
- Tweak: New icons
- Tweak: Make RSS link a tiny button in group view.
- Tweak: better rendering of sub-forum on t the main group view.
- Tweak: Make cursor a pointer when hovering over the new topic submit button.
- Tweak: Do not use rounded icons by default in the icon columns.
- New: REQUIRES SP 6.7.0

###### 1.2.0
- New: An overlay whose colors match the WP 2021 theme

###### 1.1.0
- New: An overlay whose colors match the simple:press website.
- Fix: Some private messages buttons had the incorrect font color making the text on the button hard to read.
- Fix: Set select dropdown heights to use EMs instead of hardcoding to 24px.

###### 1.0.1
- Initial public release.

###### 1.0.0
- Initial internal release.
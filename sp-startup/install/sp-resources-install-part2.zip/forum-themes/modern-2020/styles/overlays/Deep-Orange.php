<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File
Theme		:	Modern-2020
Color		:	Custom
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# load the header partial
$header_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/header.php';
include($header_partial);

# Set the colors for this theme. 
# To understand what each element is used for, look at the partials/footer.php file.
$ops = array(
'C1' => '#000000',
'C2' => '#FFFFFF',
'C3' => '#BF360C',
'C4' => '#000000',
'C5' => '#9A2500',
'C6' => '#FFF3E0',
'C7' => '#FFCCBC',
'C8' => '#9A5500',
'C9' => '#F0F0F0',
'C10' => '#870030',
'C11' => '#FFFFFF',
'C12' => '#',
'FN' => 'inherit',
'MFN' => 'inherit',
'F1' => '100',
'F2' => '100',
'FLAGNEWBG' => '#d50000',
'IP01' => '#ECEFF1',
);


# load the footer partial - this is actually where most of the colors are handled
$footer_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/footer.php';
include($footer_partial);

<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File
Theme		:	Modern-2020
Color		:	Custom
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# load the header partial
$header_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/header.php';
include($header_partial);

# Set the colors for this theme. 
# To understand what each element is used for, look at the partials/footer.php file.
$ops = array(
'C1' => '#000000',
'C2' => '#FFFFFF',
'C3' => '#28303D',
'C4' => '#000000',
'C5' => '#0D47A1',
'C6' => '#E3F2FD',
'C7' => '#D1E4DD',
'C8' => '#03A9F4',
'C9' => '#F0F0F0',
'C10' => '#2196F3',
'C11' => '#FFFFFF',
'C12' => '#',
'FN' => 'inherit',
'MFN' => 'inherit',
'F1' => '100',
'F2' => '100',
'FLAGNEWBG' => '#d50000',
'IP01' => '#ECEFF1',
);

# load the footer partial - this is actually where most of the colors are handled
$footer_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/footer.php';
include($footer_partial);

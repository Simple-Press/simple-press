<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File
Theme		:	Modern-2020
Color		:	Custom
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# load the header partial
$header_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/header.php';
include($header_partial);

# Set the colors for this theme. 
# To understand what each element is used for, look at the partials/footer.php file.
$ops = array(
'C1' => '#000000',
'C2' => '#FFFFFF',
'C3' => '#000000',
'C4' => '#000000',
'C5' => '#311B92',
'C6' => '#F5F5F5',
'C7' => '#ECEFF1',
'C8' => '#673AB7',
'C9' => '#F0F0F0',
'C10' => '#B388FF',
'C11' => '#FFFFFF',
'C12' => '#',
'FN' => 'inherit',
'MFN' => 'inherit',
'F1' => '100',
'F2' => '100',
'FLAGNEWBG' => '#d50000',
'IP01' => '#ECEFF1',
);


# load the footer partial - this is actually where most of the colors are handled
$footer_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/footer.php';
include($footer_partial);

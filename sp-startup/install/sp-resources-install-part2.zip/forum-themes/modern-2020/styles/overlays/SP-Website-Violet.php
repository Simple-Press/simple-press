<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File
Theme		:	Modern-2020
Color		:	Custom
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# load the header partial
$header_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/header.php';
include($header_partial);

# Set the colors for this theme. 
# To understand what each element is used for, look at the partials/footer.php file.
$ops = array(
'C1' => '#000000',
'C2' => '#FFFFFF',
'C3' => '#6570BE',
'C4' => '#000000',
'C5' => '#444FA4',
'C6' => '#F9F9F9',
'C7' => '#ECEFF1',
'C8' => '#367797',
'C9' => '#F0F0F0',
'C10' => '#455A64',
'C11' => '#FFFFFF',
'C12' => '#',
'FN' => 'inherit',
'MFN' => 'inherit',
'F1' => '100',
'F2' => '100',
'FLAGNEWBG' => '#d50000',
'IP01' => '#CFD8DC',
);

# load the footer partial - this is actually where most of the colors are handled
$footer_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/footer.php';
include($footer_partial);

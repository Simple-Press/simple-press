<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File
Theme		:	Modern-2020
Color		:	Custom
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# load the header partial
$header_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/header.php';
include($header_partial);

# check for custom settings
if (isset($_GET['sp-customizer-test'])) {
	require_once $rel_path.'sp-custom-settings/sp-modern2020-test-settings.php';
} else {
	require_once $rel_path.'sp-custom-settings/sp-modern2020-custom-settings.php';
}

# load the footer partial - this is actually where most of the colors are handled
$footer_partial = dirname(__FILE__).'/../../../'.$_GET['theme'].'/styles/overlays/partials/footer.php';
include($footer_partial);
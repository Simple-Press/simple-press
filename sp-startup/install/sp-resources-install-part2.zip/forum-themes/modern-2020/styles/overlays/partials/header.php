<?php

# --------------------------------------------------------------------------------------
/*
Simple:Press Template Color Attribute File - Header
Theme		:	Modern 20202
Author		:	Simple:Press
*/
# --------------------------------------------------------------------------------------

# -----------------------------------------------------------------------------------------------------------------------------------

# adjust path as needed for multisite
$site = $_GET['site'];
if (empty($site)) {
    # standard wp
    $rel_path = '../../../../'; # custom settings in wp-content
} else {
    # multisite
    # need to handle old style blogs.dir storage and wp 3.5+ storage
    if (isset($_GET['oldstore'])) {
        # old style blogs.dir storage
        $rel_path = '../../../../'; # custom settings in blogs.dir/xx/ directory
    } else {
        # wp 3.5+ storage
        if ($site == 1) {
            $rel_path = '../../../../'; # custom settings in wp-content/uploads directory for main site
        } else {
            $rel_path = "../../../../sites/$site/"; # custom settings in wp-content/uploads/sites/xx directory for network sites
        }
    }
}


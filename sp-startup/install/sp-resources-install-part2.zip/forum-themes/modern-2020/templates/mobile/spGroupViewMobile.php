<?php
# --------------------------------------------------------------------------------------
#
#	Simple:Press Template
#	Theme		:	Modern-2020
#	Template	:	Group View Mobile
#	Author		:	Simple:Press
#
#	The 'group' template is used to display the Group/Forum Index Listing for Mobile
#
# --------------------------------------------------------------------------------------

	# Load the forum header template - normally first thing
	# ----------------------------------------------------------------------
	sp_SectionStart('tagClass=spHeadContainer', 'forumHead');

		sp_load_template('spHead.php');

	sp_SectionEnd('', 'forumHead');

	sp_SectionStart('tagClass=spBodyContainer', 'forumBody');

		# Start the 'groupView' section
		# ----------------------------------------------------------------------
		sp_SectionStart('tagClass=spMobileListSection', 'groupView');

			# Start the Group Loop
			# ----------------------------------------------------------------------
			if (SP()->forum->view->has_groups()) : while (SP()->forum->view->loop_groups()) : SP()->forum->view->the_group();

				# Start the 'groupHeader' section
				# ----------------------------------------------------------------------
				sp_SectionStart('tagClass=spGroupViewSection', 'eachGroup');

					sp_SectionStart('tagClass=spGroupViewHeaderMobile', 'groupHeader');

						sp_SectionStart('tagClass=spFlexHeadContainerMobile', 'groupFlexHeader');

							sp_ColumnStart('tagId=spIconCol&tagClass=spIconColumnSectionTitle  spCenter&width=100%&height=0px');
								sp_GroupHeaderIcon('tagClass=spRowIcon spLeft');
							sp_ColumnEnd();

							sp_ColumnStart('tagId=spHeadColumn2&tagClass=spTitleColumnTitle spCenter&width=100%&height=0');
								sp_GroupHeaderName('tagClass=spHeaderName');
								sp_InsertBreak();
							sp_ColumnEnd();

							sp_ColumnStart('tagClass=spHeadColumn3 spCenter&width=auto&height=0');
								/* Not showing RSS button on mobile */
								// sp_GroupHeaderRSSButton('tagClass=spLink spRight&iconClass=spIcon&icon= spRight', __sp('RSS'), __sp('Subscribe to the RSS feed for this forum group'));
							sp_ColumnEnd();

							sp_InsertBreak();

						sp_SectionEnd('', 'groupFlexHeader');

						sp_GroupHeaderDescription('tagClass=spHeaderDescription');
						sp_InsertBreak();
						/* Not going to show the group header message on mobile */
						// sp_GroupHeaderMessage('tagClass=spHeaderMessage');
						sp_InsertBreak();

					sp_SectionEnd('', 'groupHeader');

					sp_SectionStart('tagClass=spGroupForumContainer', 'groupViewForums');

						# Start the Forum Loop
						# ----------------------------------------------------------------------
						if (SP()->forum->view->has_forums()) : while (SP()->forum->view->loop_forums()) : SP()->forum->view->the_forum();
							
							# Start the 'forum' section
							# ----------------------------------------------------------------------
                            sp_SectionStart('tagClass=spGroupViewMobileForumSection', 'eachForum');

                                sp_SectionStart('tagClass=spGroupForumHeader', 'eachForumTitle');
									sp_ForumIndexIcon('tagClass=spRowIcon spCenter');
									sp_InsertBreak();
	    							sp_UserNewPostFlag('', 'group');
		    						sp_ForumIndexName('tagClass=spRowName spGroupViewMobileForumName', __sp('Browse topics in %NAME%'));
				    				sp_InsertBreak();
									sp_ForumIndexDescription('tagClass=spRowDescription spForumIndexDescription');

							    sp_SectionEnd('', 'eachForumTitle');

                                sp_SectionStart('tagClass=spGroupForumSection', 'eachForumData');
									sp_ForumIndexLastPost('tagClass=spForumIndexLastPost&order=TLDU&&nicedate=1&date=0&time=1&stackdate=0&icon=&itemBreak=&nbsp', __sp('Last Post:'), __sp('There are no topics in this forum'));

							    	# Column 1 of the forum row
									/* There is no column #1 but if there was, it would go here. */

				    				# Column 2 of the forum row
					    			# ----------------------------------------------------------------------
									/* There is no column #2 but if there was, it would go here. */
						    
                                sp_SectionEnd('', 'eachForumData');

								sp_SectionStart('tagClass=spSubForumHolder', 'eachForumSubs');

									sp_ForumIndexSubForums('stack=0&unreadIcon=sp_SubForumUnreadIcon.png&stack=1&topicCount=0', __sp(''), __sp('Browse topics in %NAME%'));

								sp_SectionEnd('', 'eachForumSubs');
								
								sp_ForumIndexLink('tagClass=spCenter spButton spViewForumButton', __sp('View topics in %NAME%'));
								sp_InsertBreak();

								sp_ForumIndexTopicCount('tagClass=spInRowCount spMiniButton spLeft', __sp(''), __sp('Topic'), __sp('topics') );							
								sp_ForumIndexPostCount('tagClass=spInRowCount spMiniButton spLeft', __sp(''), __sp('Posts'), __sp('posts') );
								sp_ForumIndexLockIcon('tagClass=spIcon spRight', __sp('This forum is locked'));
								sp_ForumIndexAddIcon('tagClass=spIcon spRight', __sp('Add new topic in this forum'), __sp(''));
								
								sp_ForumIndexInlinePosts();
								sp_InsertBreak('spacer=15px');

								if (SP()->forum->view->forum_count() > 1) {
									sp_InsertRule();
								}
								
						sp_SectionEnd('', 'eachForum');							
						endwhile; else:
							sp_NoForumsInGroupMessage('tagClass=spMessage', __sp('There are no forums in this group'));
						endif;

					sp_SectionEnd('', 'groupViewForums');

				sp_SectionEnd('', 'eachGroup');

			endwhile; else:
				sp_NoGroupMessage('tagClass=spMessage', __sp('The requested group does not exist or you do not have permission to view it'), __sp('No groups have been created yet'));
			endif;

		sp_SectionEnd('', 'groupView');

	sp_SectionEnd('', 'forumBody');

	# Load the forum footer template - normally last thing
	# ----------------------------------------------------------------------
	sp_SectionStart('tagClass=spFootContainer', 'forumFoot');

		sp_load_template('spFoot.php');

	sp_SectionEnd('', 'forumFoot');

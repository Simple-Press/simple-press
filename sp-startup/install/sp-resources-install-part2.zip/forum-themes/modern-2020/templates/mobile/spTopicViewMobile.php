<?php
# --------------------------------------------------------------------------------------
#
#	Simple:Press Template
#	Theme		:	Modern-2020
#	Template	:	topic
#	Author		:	Simple:Press
#
#	The 'topic' template is used to display the Topic/Post Index Listing
#
# --------------------------------------------------------------------------------------

	# == ADD POST FORM - OBJECT DEFINITION ========================
	$addPostForm = array(
		'tagClass'				=> 'spForm',
		'hide'					=> 1,
		'controlFieldset'		=> 'spEditorFieldset',
		'controlInput'			=> 'spControl',
		'controlSubmit'			=> 'spSubmit',
		'controlOrder'			=> 'cancel|save',
		'labelHeading'			=> __sp('Add Reply'),
		'labelGuestName'		=> __sp('Guest name (required)'),
		'labelGuestEmail'		=> __sp('Guest email (required)'),
		'labelModerateAll'		=> __sp('NOTE: new posts are subject to administrator approval before being displayed'),
		'labelModerateOnce'		=> __sp('NOTE: first posts are subject to administrator approval before being displayed'),
		'labelSmileys'			=> __sp('Smileys'),
		'labelOptions'			=> __sp('Options'),
		'labelOptionLock'		=> __sp('Lock this topic'),
		'labelOptionPin'		=> __sp('Pin this post'),
		'labelOptionTime'		=> __sp('Edit post timestamp'),
		'labelMath'				=> __sp('Math Required'),
		'labelMathSum'			=> __sp('What is the sum of'),
		'labelPostButtonReady'	=> __sp('Submit Reply'),
		'labelPostButtonMath'	=> __sp('Do Math To Save'),
		'labelPostCancel'		=> __sp('Cancel'),
		'tipSmileysButton'		=> __sp('Open/Close to Add a Smiley'),
		'tipOptionsButton'		=> __sp('Open/Close to select Posting Options'),
		'tipSubmitButton'		=> __sp('Save the New Post'),
		'tipCancelButton'		=> __sp('Cancel the New Post'),
		'iconMobileSubmit'		=> 'sp_EditorSave.png',
		'iconMobileCancel'		=> 'sp_EditorCancel.png',
		'iconMobileSmileys'		=> 'sp_EditorSmileys.png',
		'iconMobileOptions'		=> 'sp_EditorOptions.png'
	);

	# == EDIT POST FORM - OBJECT DEFINITION ========================
	$editPostForm = array(
		'tagClass'				=> 'spForm',
		'controlFieldset'		=> 'spEditorFieldset',
		'controlInput'			=> 'spControl',
		'controlSubmit'			=> 'spSubmit',
		'controlOrder'			=> 'cancel|save',
		'labelHeading'			=> __sp('Edit Post'),
		'labelSmileys'			=> __sp('Smileys'),
		'labelPostButton'		=> __sp('Save Edited Post'),
		'labelPostCancel'		=> __sp('Cancel'),
		'tipSmileysButton'		=> __sp('Open/Close to Add a Smiley'),
		'tipSubmitButton'		=> __sp('Save the Edited Post'),
		'tipCancelButton'		=> __sp('Cancel the Post Edits'),
		'iconMobileSubmit'		=> 'sp_EditorSave.png',
		'iconMobileCancel'		=> 'sp_EditorCancel.png',
		'iconMobileSmileys'		=> 'sp_EditorSmileys.png',
		'iconMobileOptions'		=> 'sp_EditorOptions.png'
	);
	
	# == GET PUSH NOTIFICATIONS DEFINITION =========================
	$nots = SP()->options->get('push-notifications');

	# ==============================================================

	# Load the forum header template - normally first thing
	# ----------------------------------------------------------------------
	sp_SectionStart('tagClass=spHeadContainer', 'forumHead');

		sp_load_template('spHead.php');

	sp_SectionEnd('', 'forumHead');

	sp_SectionStart('tagClass=spBodyContainer', 'forumBody');

		# Start the 'topicView' section
		# ----------------------------------------------------------------------
		sp_SectionStart('tagClass=spListSection', 'topicView');

			# Set the Topic
			# ----------------------------------------------------------------------
			if (SP()->forum->view->this_topic()):

				# Start the 'topicHeader' section
				# ----------------------------------------------------------------------
				sp_SectionStart('tagClass=spTopicViewSection', 'eachTopic');

					sp_SectionStart('tagClass=spTopicViewHeader', 'topicHeader');

						sp_SectionStart('tagClass=spFlexHeadContainer', 'topicFlexHeader');

							sp_ColumnStart('tagId=spIconCol&tagClass=spIconColumnSectionTitle  spLeft&width=0&height=0px');
								sp_TopicHeaderIcon('tagClass=spHeaderIcon spLeft');
								sp_TopicHeaderName('tagClass=spHeaderName spRight');
							sp_ColumnEnd();
							
							if (function_exists('sp_TopicHeaderShowBlogLink')) sp_TopicHeaderShowBlogLink('tagClass=spMiniButton&icon=', __sp('Read the original blog post'), __sp('Click to go to original blog post'));
							sp_InsertBreak();

							/* no RSS in mobile */
							/*							sp_ColumnStart('tagId=spHeadColumn3&tagClass=spTitleColumnTitle spRight&width=5%&height=0');								
								sp_TopicHeaderRSSButton('tagClass=spLink spRight&icon=', __sp('RSS'), __sp('Subscribe to the RSS feed for this topic'));
								sp_InsertBreak();
							sp_ColumnEnd();
							sp_InsertBreak();
							*/

						sp_SectionEnd('', 'topicFlexHeader');

						sp_SectionStart('tagClass=statusHolder', 'topicHeadPlugins');

							sp_InsertBreak();
							if (function_exists('sp_TopicStatus')) sp_TopicStatus('tagClass=spTopicViewStatus spLeft&statusClass=spRight spTopicStatus&icon=', __sp('Search for other topics with this status'), '');
							sp_InsertBreak();
							if (function_exists('sp_TopicTagsList')) sp_TopicTagsList('tagClass=spTopicTagsList spLeft&icon=', __sp(''));

						sp_SectionEnd('', 'topicHeadPlugins');

						sp_InsertBreak();

						# Header Buttons Section
						# ----------------------------------------------------------------------
						sp_SectionStart('tagClass=spActionsBar spActionsBarHeader', 'topicHeadButtons');
							sp_PostNewButton('tagClass=spAccentButton spRight&icon=', __sp('Add Reply'), __sp('Add a new post in this topic'), __sp('This topic is locked'));
							
							if (function_exists('sp_PushNotificationsSubscribeButton')){
								if(get_user_meta(get_current_user_id(), 'pushover_key', true) != '' && $nots['pushover'] != ''){
									sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-PushOver.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-PushOver.png', __sp(''), __sp(''), __sp('Subscribe to this topic with Pushover'), __sp('Unsubscribe from this topic (Pushover)'), 'pushover', SPACTIVITY_SUBS_PUSHOVER_TOPIC);
								}
								if(get_user_meta(get_current_user_id(), 'pushbullet_key', true) != '' && $nots['pushbullet'] != ''){
									sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-PushBullet.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-PushBullet.png', __sp(''), __sp(''), __sp('Subscribe to this topic with PushBullet'), __sp('Unsubscribe from this topic (PushBullet)'), 'pushbullet', SPACTIVITY_SUBS_PUSHBULLET_TOPIC);
								}
								if(get_user_meta(get_current_user_id(), 'slack_key', true) != ''){
									sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-Slack.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-Slack.png', __sp(''), __sp(''), __sp('Subscribe to this topic with Slack'), __sp('Unsubscribe from this topic (Slack)'), 'slack', SPACTIVITY_SUBS_SLACK_TOPIC);
								}
								if(get_user_meta(get_current_user_id(), 'twiliosms_key', true) != '' && $nots['twiliosms-account-sid'] != ''){
									sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-SMS.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-SMS.png', __sp(''), __sp(''), __sp('Subscribe to this topic with SMS'), __sp('Unsubscribe from this topic (SMS)'), 'twiliosms', SPACTIVITY_SUBS_TWILIOSMS_TOPIC);
								}
							}
							
							if (function_exists('sp_SubscriptionsSubscribeButton')) sp_SubscriptionsSubscribeButton('tagClass=spMiniButton spRight&subscribeIcon=&unsubscribeIcon=', __sp('Subscribe'), __sp('Unsubscribe'), 'Subscribe to this topic with EMAIL notifications', 'Unsubscribe from this topic (EMAIL)');
							if (function_exists('sp_WatchesWatchButton')) sp_WatchesWatchButton('tagClass=spMiniButton spRight&watchIcon=&stopWatchIcon=', __sp('Watch'), __sp('Un-Watch'), '', '');
						sp_SectionEnd('tagClass=spClear', 'topicHeadButtons');

						sp_InsertBreak();

					sp_SectionEnd('', 'topicHeader');

					sp_InsertBreak('spacer=5px');

					sp_SectionStart('tagClass=spTopicPostContainer', 'topicViewPosts');

						# Start the Post Loop
						# ----------------------------------------------------------------------
						if (SP()->forum->view->has_posts()) : while (SP()->forum->view->loop_posts()) : SP()->forum->view->the_post();

							# Start the 'post' section
							# ----------------------------------------------------------------------
							sp_SectionStart('tagClass=spTopicPostSection', 'eachPost');

								sp_PostIndexAnchor();

								sp_SectionStart('', 'postUser');

									sp_PostIndexNumber('tagClass=spPostNumber spLeft');
									sp_UserNewPostFlag('', 'topic');
									sp_PostIndexUserDate('tagClass=spPostUserDate spLeft&stackdate=0');
									sp_OpenCloseControl("targetId=spPostAction&context=postLoop&linkClass=spAccentButton spOpenCloseControlButton spRight&default=closed&setCookie=0&asLabel=1", __sp('Post Actions'), __sp('Hide'));

									# Start the 'post' section
									# ----------------------------------------------------------------------

									sp_InsertBreak('');

									sp_SectionStart("tagId=spPostAction&context=postLoop&tagClass=spPostActionSection", 'postActionButtons');

										sp_SectionStart("tagId=&tagClass=spFlexHolder&context=postLoop", 'postFlexActionButtons');

											sp_PostForumToolButton("tagClass=spAccentButton spPostActionLabel spLeft&hide=0&icon=", __sp('Tools'), __sp('Open the forum toolset'));
											sp_PostIndexPrint('tagClass=spAccentButton spPostActionLabel spLeft&icon=', __sp('Print'), __sp('Print this post'));

											if (function_exists('sp_PostIndexDeleteThread')) {
												sp_PostIndexDeleteThread('tagClass=spAccentButton spPostActionLabel spLeft&icon=', __sp('Delete'), __sp('Delete'), __sp('Delete this thread'), __sp('Delete this post'));
											} else {
												sp_PostIndexDelete('tagClass=spAccentButton spPostActionLabel spLeft&icon=', __sp('Delete'), __sp('Delete this post'));
											}

											sp_PostIndexEdit('tagClass=spAccentButton spPostActionLabel spLeft&icon=', __sp('Edit'), __sp('Edit this post'));
											sp_PostIndexQuote('tagClass=spAccentButton spPostActionLabel spRight&icon=', __sp('Quote'), __sp('Quote this post'));

											if (function_exists('sp_PostIndexThreadedReply')) sp_PostIndexThreadedReply('tagClass=spAccentButton spPostActionLabel spRight&icon=', __sp('Reply'), __sp('Reply to this post'));

											if (function_exists('sp_thanks_thank_the_post')) sp_thanks_thank_the_post('tagClass=spAccentButton spPostActionLabel spRight&iconThanks=&iconThanked=', __sp('Thanks'), __sp('Thanked'), __sp('Add thanks to this post'), __sp('You have already thanked this post'));
											if (function_exists('sp_PostIndexReportPost')) sp_PostIndexReportPost('tagClass=spAccentButton spPostActionLabel spRight&icon=', __sp('Report'), __sp('Report this post to admin'));

										sp_SectionEnd('', 'postFlexActionButtons');

									sp_SectionEnd('', 'postActionButtons');

								sp_SectionEnd('', 'postUser');

								# User Info post row
								# ----------------------------------------------------------------------
								sp_SectionStart('tagClass=spUserSectionMobile', 'postUserMobile');

									sp_InsertBreak('');

									sp_ColumnStart('tagClass=spAvatarSection spLeft&width=70%&height=15px');
										sp_UserAvatar('tagClass=spPostUserAvatar spLeft&context=user', SP()->forum->view->thisPostUser);
										sp_PostIndexUserName('tagClass=spPostUserName spLeft');
										sp_InsertLineBreak();
										if (function_exists('sp_PostIndexUserLocation')) { sp_PostIndexUserLocation('tagClass=spPostUserLocation spLeft');
											sp_InsertLineBreak();
										}
										sp_PostIndexUserPosts('tagClass=spPostUserPosts spLeft', __sp('Posts: %COUNT%'));
										sp_InsertBreak('');

										sp_SectionStart('tagClass=spIdentitySection', 'postUserIdentities');

											sp_PostIndexUserWebsite('tagClass=spLeft', __sp('Visit my website'));
											sp_PostIndexUserTwitter('tagClass=spLeft', __sp('Follow me on Twitter'));
											sp_PostIndexUserFacebook('tagClass=spLeft', __sp('Connect with me on Facebook'));
											sp_PostIndexUserMySpace('tagClass=spLeft', __sp('See MySpace'));
											sp_PostIndexUserLinkedIn('tagClass=spLeft', __sp('My LinkedIn network'));
											sp_PostIndexUserYouTube('tagClass=spLeft', __sp('View my YouTube channel'));
											sp_PostIndexUserGooglePlus('tagClass=spLeft', __sp('Interact with me on Google Plus'));
											sp_InsertLineBreak();

										sp_SectionEnd('', 'postUserIdentities');

									sp_ColumnEnd();

									sp_ColumnStart('tagClass=spUserStatsSection spRight&width=30%&height=20px');
										sp_ColumnStart('tagClass=spIdentityHolder spRight&width=auto&height=auto');
											sp_PostIndexUserBadges('tagClass=spCenter');
											sp_InsertBreak('');
											if (function_exists('sp_PostIndexCubePoints')) {
												sp_InsertBreak();
												sp_PostIndexCubePoints('tagClass=spPostUserCubePoints', __sp('CubePoints'));
											}
											sp_InsertBreak('');
											if (function_exists('sp_PostIndexUserReputationLevel')) sp_PostIndexUserReputationLevel('tagClass=spPostReputationLevel spCenter');
											if (function_exists('sp_PostIndexRepUser')) sp_PostIndexRepUser('tagClass=spCenter', __sp('Reputation'), __sp('Give/Take Reputation'));
											sp_InsertBreak();
										sp_ColumnEnd();
									sp_ColumnEnd();

								sp_SectionEnd('tagClass=spClear', 'postUserMobile');

								# Post Content post row
								# ----------------------------------------------------------------------
								sp_SectionStart('tagClass=spPostSection', 'postContentBox');

									sp_SectionStart('tagClass=spPostContentSection', 'postContent');

										if (function_exists('sp_PostIndexRatePost')) {
											sp_PostIndexRatePost('tagClass=spRight');
											sp_InsertBreak();
										}
										sp_PostIndexContent('', __sp('Awaiting Moderation'));
										sp_InsertBreak();
										if (function_exists('sp_ShareThisTopicIndexTag') || function_exists('sp_AnswersTopicAnswer') || function_exists('sp_thanks_thanks_for_post')){

//											sp_ColumnStart('tagClass=spPluginSection spCenter&height=auto');
												if (function_exists('sp_ShareThisTopicIndexTag')) sp_ShareThisTopicIndexTag('tagClass=ShareThisTopicIndex spRight');
												if (function_exists('sp_AnswersTopicAnswer')) {
												if (SP()->forum->view->thisPost->post_index == 1) sp_AnswersTopicSeeAnswer('tagClass=spAnswersTopicSeeAnswer spPostButton spRight&icon=', __sp('See Answer'), __sp('Go to the post marked as the answer'));
													sp_InsertBreak();
													sp_AnswersTopicAnswer('tagClass=spAnswersTopic&icon=sp_Check.png',  __sp('This post answers the topic'), __sp('This post answers the topic'));
													sp_AnswersTopicPostIndexAnswer('tagClass=spAnswersTopicAnswersButton spPostButton spRight&markIcon=&unmarkIcon', __sp('Answers Question'), __sp('Mark this post as topic answer'), __sp('Make Unaswered'), __sp('Unmark this post as topic answer'));
												}
//											sp_ColumnEnd();

											if (function_exists('sp_thanks_thanks_for_post')) {
												sp_InsertBreak();
												sp_thanks_thanks_for_post();
											}
											sp_InsertBreak();
										}
										
										sp_PostNewButton('tagClass=spAccentButton spLeft&icon=', __sp('Add Reply'), __sp('Add a new post in this topic'), __sp('This topic is locked'));
										sp_InsertBreak();
										
									sp_SectionEnd('', 'postContent');

								sp_SectionEnd('', 'postContentBox');

								sp_PostIndexUserSignature('tagClass=spPostUserSignature spCenter&maxHeightBottom=');

								sp_InsertBreak();

							sp_SectionEnd('', 'eachPost');

						endwhile; else:
							sp_NoPostsInTopicMessage('tagClass=spMessage', __sp('There are no posts in this topic'));
						endif;

					sp_SectionEnd('', 'topicViewPosts');

				sp_SectionEnd('', 'eachTopic');

				sp_UsersAlsoViewing('includeAdmins=1&includeMods=1&includeMembers=1&displayToAll=1', __sp('Is viewing'));

				sp_SectionStart('tagClass=spPageLinksBottom', 'topicPageLinksFoot');

					sp_PostIndexPageLinks('tagClass=spPageLinks spPageLinksBottom spRight&prevIcon=&nextIcon=&showLinks=2&showEmpty=1', '', __sp('Jump to page %PAGE% of this topic'), __sp('Jump to page'));

				sp_SectionEnd('', 'topicPageLinksFoot');

				# Start the 'editor' section
				# ----------------------------------------------------------------------
				sp_SectionStart('tagClass=spHiddenSection', 'postEditor');
                                
                                        if(function_exists('sp_CannedRepliesButton')) sp_CannedRepliesButton ('', __sp('Canned Replies'), __sp('Open Canned Replies'));
					sp_PostEditorWindow($addPostForm, $editPostForm);

				sp_SectionEnd('', 'postEditor');

			else:
				sp_NoTopicMessage('tagClass=spMessage', __sp('Access denied - you do not have permission to view this page'), __sp('The requested topic does not exist'));
			endif;

		sp_SectionEnd('', 'topicView');

	sp_SectionEnd('', 'forumBody');

	sp_InsertBreak();

	# Footer Buttons Section
	# ----------------------------------------------------------------------
	sp_SectionStart('tagClass=spActionsBar', 'topicFooterButtons');

		sp_PostNewButton('tagClass=spAccentButton spRight&icon=', __sp('Add Reply'), __sp('Add a new post in this topic'), __sp('This topic is locked'));
		
		if (function_exists('sp_PushNotificationsSubscribeButton')){
			if(get_user_meta(get_current_user_id(), 'pushover_key', true) != '' && $nots['pushover'] != ''){
				sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-PushOver.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-PushOver.png', __sp(''), __sp(''), __sp('Subscribe to this topic with Pushover'), __sp('Unsubscribe from this topic (Pushover)'), 'pushover', SPACTIVITY_SUBS_PUSHOVER_TOPIC);
			}
			if(get_user_meta(get_current_user_id(), 'pushbullet_key', true) != '' && $nots['pushbullet'] != ''){
				sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-PushBullet.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-PushBullet.png', __sp(''), __sp(''), __sp('Subscribe to this topic with PushBullet'), __sp('Unsubscribe from this topic (PushBullet)'), 'pushbullet', SPACTIVITY_SUBS_PUSHBULLET_TOPIC);
			}
			if(get_user_meta(get_current_user_id(), 'slack_key', true) != ''){
				sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-Slack.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-Slack.png', __sp(''), __sp(''), __sp('Subscribe to this topic with Slack'), __sp('Unsubscribe from this topic (Slack)'), 'slack', SPACTIVITY_SUBS_SLACK_TOPIC);
			}
			if(get_user_meta(get_current_user_id(), 'twiliosms_key', true) != '' && $nots['twiliosms-account-sid'] != ''){
				sp_PushNotificationsSubscribeButton('tagClass=spFootButton spRight&subscribePushNotificationsIcon=sp_PushNotificationsSubscribeButton-SMS.png&unsubscribePushNotificationsIcon=sp_PushNotificationsUnsubscribeButton-SMS.png', __sp(''), __sp(''), __sp('Subscribe to this topic with SMS'), __sp('Unsubscribe from this topic (SMS)'), 'twiliosms', SPACTIVITY_SUBS_TWILIOSMS_TOPIC);
			}
		}
		
		if (function_exists('sp_SubscriptionsSubscribeButton')) sp_SubscriptionsSubscribeButton('tagClass=spMiniButton spRight&subscribeIcon=&unsubscribeIcon=', __sp('Subscribe'), __sp('Unsubscribe'), 'Subscribe to this topic with EMAIL notifications', 'Unsubscribe (EMAIL)');
		if (function_exists('sp_WatchesWatchButton')) sp_WatchesWatchButton('tagClass=spMiniButton spRight&watchIcon=&stopWatchIcon=', __sp('Watch'), __sp('Un-Watch'), '', '');

	sp_SectionEnd('tagClass=spClear', 'topicFooterButtons');


	# Load the forum footer template - normally last thing
	# ----------------------------------------------------------------------
	sp_SectionStart('tagClass=spFootContainer', 'forumFoot');

		sp_load_template('spFoot.php');

	sp_SectionEnd('', 'foprumFoot');

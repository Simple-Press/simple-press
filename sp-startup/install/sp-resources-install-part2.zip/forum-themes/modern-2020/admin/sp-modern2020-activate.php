<?php
/*
Simple:Press
Modern 2020 Custom Options Setup Routine
$LastChangedDate: 2014-05-17 21:16:12 +0100 (Sat, 17 May 2014) $
$Rev: 11442 $
*/

if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');

function sp_modern_2020_setup($check = true) {
    # install picks up wrong SF STORE DIR so lets recalculate it for installs
    if (is_multisite() && !get_site_option('ms_files_rewriting')) {
        $uploads = wp_get_upload_dir();
        if (!defined('STORE_DIR'))		define('STORE_DIR',   $uploads['basedir']);
    } else {
        if (!defined('STORE_DIR'))		define('STORE_DIR',   WP_CONTENT_DIR);
    }

	# if exists then get right out
	if ($check) {
		if (file_exists(STORE_DIR.'/'.'sp-custom-settings/sp-modern2020-custom-settings.php')) return;
	}

	# create folder of not exists
	$perms = fileperms(STORE_DIR);
	if ($perms === false) $perms = 0755;

	if (!file_exists(STORE_DIR.'/'.'sp-custom-settings')) {
		@mkdir(STORE_DIR.'/'.'sp-custom-settings', $perms);
	}

	# compile default file contents
	$C1 = '#000000';
	$C2 = '#FFFFFF';
	$C3 = '#27476E';
	$C4 = '#006992';
	$C5 = '#00B9D0';
	$C6 = '#F9F9F9';
	$C7 = '#EAF0F4';
	$C8 = '#ECA400';
	$C9 = '#F0F0F0';
	$C10 = '#89A5D4';
	$C11 = '#FFFFFF';
	$C12 = 'transparent';
	$FN = 'inherit';
	$F1 = '100';
	$MFN = 'inherit';
	$F2 = '100';
	$FLAGNEWBG = '#d50000';
	$IP01 = '#ECEFF1';
	
	$ops = "<?php\n";
	$ops.= "\$ops = array(\n";
	$ops.= "'C1' => '".$C1."',\n";
	$ops.= "'C2' => '".$C2."',\n";
	$ops.= "'C3' => '".$C3."',\n";
	$ops.= "'C4' => '".$C4."',\n";
	$ops.= "'C5' => '".$C5."',\n";
	$ops.= "'C6' => '".$C6."',\n";
	$ops.= "'C7' => '".$C7."',\n";
	$ops.= "'C8' => '".$C8."',\n";
	$ops.= "'C9' => '".$C9."',\n";
	$ops.= "'C10' => '".$C10."',\n";
	$ops.= "'C11' => '".$C11."',\n";
	$ops.= "'C12' => '".$C12."',\n";
	$ops.= "'FN' => '".$FN."',\n";
	$ops.= "'MFN' => '".$MFN."',\n";
	$ops.= "'F1' => '".$F1."',\n";
	$ops.= "'F2' => '".$F2."',\n";
	$ops.= "'FLAGNEWBG' => '".$FLAGNEWBG."',\n";
	$ops.= "'IP01' => '".$IP01."',\n";
	$ops.= ");\n?>";

	$files = array();
	$files[] = STORE_DIR.'/'.'sp-custom-settings/sp-modern2020-custom-settings.php';
	$files[] = STORE_DIR.'/'.'sp-custom-settings/sp-modern2020-test-settings.php';

	foreach($files as $file) {
		$f = fopen($file, 'w');
		if ($f !== false) {
			fwrite($f, $ops);
			fclose($f);
		}
	}

	# Not sure of there is any real way to send message of success or failure.
	return;
}

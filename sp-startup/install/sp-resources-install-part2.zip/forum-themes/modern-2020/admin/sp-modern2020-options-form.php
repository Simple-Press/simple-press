 <?php
/*
Simple:Press
Modern 2020 SP Theme Custom Settings Form
$LastChangedDate: 2014-09-12 07:30:12 +0100 (Fri, 12 Sep 2014) $
$Rev: 11958 $
*/

if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');

function sp_modern_2020_options_form() {

	if (!SP()->auths->current_user_can('SPF Manage Themes')) {
		SP()->primitives->admin_etext('Access denied - you do not have permission');
		die();
	}

	require_once SPMOD2020ADMIN.'sp-modern2020-activate.php';
	sp_modern_2020_setup(true);
?>

<style>
	.color-picker { height: 50px; }
</style>

<script>
	jQuery(document).ready(function($) {
		var colorPickers = $('.color-picker');
		for (e in colorPickers) {
			if (colorPickers[e].id != undefined) {
				var colorPickerID = colorPickers[e].id;
				$('#' + colorPickerID + '-color').farbtastic('#' + colorPickerID);
			}
		}

		$('.fabox').hide();

		$('.color-picker').click(function() {
			$(this).parent().find('.fabox').fadeIn();
		});

		$(document).mousedown(function() {
			$('.fabox').each(function() {
				var display = $(this).css('display');
				if (display == 'block') $(this).fadeOut();
			});
		});
	});

	function spjLoadTestView(url, title) {
		var aWidth = (window.innerWidth-80);
		var aHeight = (window.innerHeight-80);
		spj.dialogAjax(this, url, title, aWidth, aHeight, 'center');
	}
</script>

<?php

	require_once SP_STORE_DIR.'/'.'sp-custom-settings/sp-modern2020-test-settings.php';

	spa_paint_options_init();

	spa_paint_open_tab(__('Modern 2020 Custom Theme Settings', 'spBarebones'), true);
	
?>

<div class="sfoptionerror">
	<div class="spLeft" style="font-size: 13px;float: left;margin-right: 60px;">
		<span style="font-weight:bold"><?php SP()->primitives->admin_etext('Before using this customizer we strongly recommend you click on the help button and familiarize yourself with how it works to avoid inadvertently altering your live forum display'); ?></span>
	</div>
		<div class="spRight" style="right: 16px;top: 16px;position: absolute;float: right;"><?php echo spa_paint_help( 'custom-options', 'admin-themes' ); ?></div>

	<div class="clear"></div>
	<br />
</div>
	
<?php
		echo '<div class="sp-half-form">';

		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
?>

			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Primary Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for headers and some labels','modern2020')?></small></p>
					<input id="C3" class="color-picker" type="text" value="<?php echo $ops['C3']; ?>" name="C3" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C3-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>			
			
			<div>
				<div style="width: 49.5%; float:right;">
					<p><b><?php echo __('Secondary Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for regular text and some labels','modern2020')?></small></p>				
					<input id="C4" class="color-picker" type="text" value="<?php echo $ops['C4']; ?>" name="C4" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C4-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>
			
			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Tertiary Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for most buttons','modern2020')?></small></p>				
					<input id="C5" class="color-picker" type="text" value="<?php echo $ops['C5']; ?>" name="C5" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C5-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>

			<div>
				<div style="width: 49.5%; float:right;">
					<p><b><?php echo __('Primary Accent Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for some buttons and links','modern2020')?></small></p>				
					<input id="C8" class="color-picker" type="text" value="<?php echo $ops['C8']; ?>" name="C8" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C8-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>	

			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Primary background','modern2020')?></b></p>
					<p><small><?php echo __('This is the main background color that all other elements are placed in','modern2020')?></small></p>				
					<input id="C6" class="color-picker" type="text" value="<?php echo $ops['C6']; ?>" name="C6" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C6-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>

				<div style="width: 49.5%; float:right;">
					<p><b><?php echo __('Secondary Background Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for section headers','modern2020')?></small></p>				
					<input id="C7" class="color-picker" type="text" value="<?php echo $ops['C7']; ?>" name="C7" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C7-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>
			
			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Black Shade','modern2020')?></b></p>
					<p><small><?php echo __('Black is not currently used in this theme - here for future use','modern2020')?></small></p>				
					<input id="C1" class="color-picker" type="text" value="<?php echo $ops['C1']; ?>" name="C1" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C1-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>

				<div style="width: 49.5%; float:right;">
					<p><b><?php echo __('White Shade','modern2020')?></b></p>
					<p><small><?php echo __('You can change how white is rendered for most areas of the theme','modern2020')?></small></p>				
					<input id="C2" class="color-picker" type="text" value="<?php echo $ops['C2']; ?>" name="C2" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C2-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
				
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Standard Gray Shade','modern2020')?></b></p>
					<p><small><?php echo __('Gray is used as an accent for many areas - you can change its shade here or make it a completely different color.','modern2020')?></small></p>				
					<input id="C9" class="color-picker" type="text" value="<?php echo $ops['C9']; ?>" name="C9" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C9-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
				
				<div style="width: 49.5%; float:right;">
					<p><b><?php echo __('Secondary Accent Color Color','modern2020')?></b></p>
					<p><small><?php echo __('Used for tiny buttons and labels','modern2020')?></small></p>				
					<input id="C10" class="color-picker" type="text" value="<?php echo $ops['C10']; ?>" name="C10" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C10-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>				
			</div>				
<?php
			spa_paint_close_fieldset();
		spa_paint_close_panel();
		
		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
			
				spa_paint_input(__('Font Family(s) in CSS format', 'modern2020'), 'FN', $ops['FN']);
				spa_paint_input(__('Base Font Size (as percentage value)', 'modern2020'), 'F1', $ops['F1']);

			spa_paint_close_fieldset();
		spa_paint_close_panel();
		
?>


		<!--- Input Elements---->
		<br />
		<h3><?php echo __('Input Elements','modern2020')?></h3>
		<hr />
	
<?php
		
		
		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
?>

			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Border','modern2020')?></b></p>
					<p><small><?php echo __('Border color used on things like text boxes and text areas','modern2020')?></small></p>
					<input id="IP01" class="color-picker" type="text" value="<?php echo $ops['IP01']; ?>" name="IP01" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="IP01-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>
	
<?php
			spa_paint_close_fieldset();
		spa_paint_close_panel();
		
		
?>



		<!--- Flags---->
		<br />
		<h3><?php echo __('Flags','modern2020')?></h3>
		<hr />
	
<?php
		
		
		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
?>

			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('New Flag: Background Color','modern2020')?></b></p>
					<input id="FLAGNEWBG" class="color-picker" type="text" value="<?php echo $ops['FLAGNEWBG']; ?>" name="FLAGNEWBG" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="FLAGNEWBG-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>
	
<?php
			spa_paint_close_fieldset();
		spa_paint_close_panel();
		
		
?>
		<!--- Mobile---->
		<br />
		<h3><?php echo __('Mobile Overrides','modern2020')?></h3>
		<hr />
	
<?php
		
		
		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
?>

			<div>
				<div style="width: 49.5%; float:left;">
					<p><b><?php echo __('Mobile: Background Color','modern2020')?></b></p>
					<input id="C11" class="color-picker" type="text" value="<?php echo $ops['C11']; ?>" name="C11" style="width:60%;font-weight:bold;float:left;" />
					<div class="clearleft"></div>
					<div id="C11-color" class="fabox" style="margin: 0px auto; width: 195px; float:left;"></div>
				</div>
			</div>
	
<?php
			spa_paint_close_fieldset();
		spa_paint_close_panel();
		

		spa_paint_open_panel();
			spa_paint_open_fieldset('', false, '', false);
			
				spa_paint_input(__('Mobile: Font Family(s) in CSS format', 'modern2020'), 'MFN', $ops['MFN']);
				spa_paint_input(__('Mobile: Base Font Size (as percentage value)', 'modern2020'), 'F2', $ops['F2']);

			spa_paint_close_fieldset();
		spa_paint_close_panel();
		
		spa_paint_tab_right_cell();

	spa_paint_close_container();
	
	echo('<br /');	
}

function sp_modern_2020_update_bar_custom($bar) {

	$bar = '<input type="submit" name="commit-test" class="button-primary sf-button-primary" value="'.__("Update For Test", "spBarebones").'" />';
	$url = SPAJAXURL.'display-forum-custom';
	$title = __("Testing Custom Theme Settings", "spBarebones");
	$bar.= "&nbsp;&nbsp;&nbsp;<input type='button' value='View Test' class='button-primary sf-button-primary' id='df' onclick='spjLoadTestView(\"$url\", \"$title\");'/>";
	$bar.= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="commit-save" class="button-primary sf-button-primary" value="'.__("Commit Custom Settings", "spBarebones").'" />';
	$bar.= '&nbsp;&nbsp;&nbsp;<input type="submit" name="commit-reset" class="button-primary sf-button-primary" style="float:right;" value="'.__("Reset to Defaults", "spBarebones").'" />';

	return $bar;
}

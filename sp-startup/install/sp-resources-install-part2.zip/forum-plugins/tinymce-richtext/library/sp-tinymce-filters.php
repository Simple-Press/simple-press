<?php
/*
Simple:Press
TinyMCE Editor plugin content filters
$LastChangedDate: 2017-08-05 00:56:34 -0500 (Sat, 05 Aug 2017) $
$Rev: 15487 $
*/

if (preg_match('#'.basename(__FILE__).'#', $_SERVER['PHP_SELF'])) die('Access denied - you cannot directly call this file');

# ----------------------------------------------
# Prepare content for an edit action
# ----------------------------------------------
if ( ! function_exists('sp_editor_prepare_edit_content') ) {
	function sp_editor_prepare_edit_content($content, $editor) {
		return $content;
	}
}

# ----------------------------------------------
# Save Filter - Parse for codetags
# ----------------------------------------------
if ( ! function_exists('sp_editor_parse_codetags') ) {
	function sp_editor_parse_codetags($content, $editor, $action) {
		if ($editor == RICHTEXT) {
		   $content = sp_RTE2Html(' '.$content);
		}
		return $content;
	}
}

# ----------------------------------------------
# Save Filter - Save codetags and callback
# ----------------------------------------------
if ( ! function_exists('sp_editor_save_codetags') ) {
	function sp_editor_save_codetags($content, $editor) {
		if ($editor == RICHTEXT) {
			$content = preg_replace_callback('/\<div class=\"sfcode\"\>(.*?)\<\/div\>/ms', 'sp_codetag_callback', stripslashes($content));
		}
		return $content;
	}
}

if ( ! function_exists('sp_codetag_callback') ) {
	function sp_codetag_callback($s) {
		$content = str_replace('<br />', '', $s[1]);
		$content = str_replace("\n", '', $content);
		$content = '<div class="sfcode">'.$content.'</div>';
		return $content;
	}
}

# ----------------------------------------------
# Save Filter - Save linebreaks filter
# ----------------------------------------------
if ( ! function_exists('sp_editor_save_linebreaks') ) {
	function sp_editor_save_linebreaks($content, $editor) {
		return $content;
	}
}

# ----------------------------------------------
# Edit Filter - Prepare p and br tags for edit
# ----------------------------------------------
if ( ! function_exists('sp_editor_format_paragraphs_edit') ) {
	function sp_editor_format_paragraphs_edit($content, $editor) {
		if ($editor == RICHTEXT) {
			$content = SP()->displayFilters->paragraphs($content);
		}
		return $content;
	}
}

# ----------------------------------------------
# Edit Filter - Not needed for tinymce
# ----------------------------------------------
if ( ! function_exists('sp_editor_parse_for_edit') ) {
	if ( ! function_exists('sp_editor_parse_for_edit') ) {
		function sp_editor_parse_for_edit($content, $editor) {
			return $content;
		}
	}
}

# ----------------------------------------------
# Parser: Rich Text to HTML
# ----------------------------------------------
if ( ! function_exists('sp_RTE2Html') ) {
	function sp_RTE2Html($text) {
		$text = trim($text);

		# RTE-TM-Code
		if (!function_exists('rtetohtml_escape')) {
			function rtetohtml_escape($s) {
				global $text;
				return '<div class="sfcode">'.str_replace('"', '&quot;', $s[1]).'</div>';
			}
		}
		$text = preg_replace_callback('/\<div class=\"sfcode\"\>(.*?)\<\/div\>/ms', 'rtetohtml_escape', $text);
		return $text;
	}
}